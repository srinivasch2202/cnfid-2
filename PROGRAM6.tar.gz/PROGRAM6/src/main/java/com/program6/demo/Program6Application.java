package com.program6.demo;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program6Application {

	public static void main(String[] args) {
		SpringApplication.run(Program6Application.class, args);
	}
    @Bean
    public CommandLineRunner demo(StudentRepository studentRepository) {
        return (args) -> {
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("1: Insert");
                System.out.println("2: Display");
                System.out.println("3: Exit");
                System.out.print("Make your choice: ");

                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        insertStudent(scanner, studentRepository);
                        break;
                    case 2:
                        displayStudents(studentRepository);
                        break;
                    case 3:
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice! Please make a valid choice.\n");
                }
            }
        };
    }

    private void insertStudent(Scanner scanner, StudentRepository studentRepository) {
        Student student = new Student();

        System.out.print("Enter the Student usn: ");
        student.setUsn(scanner.next());

        System.out.print("Enter the Student name: ");
        student.setName(scanner.next());

        System.out.print("Enter the Student address: ");
        student.setAddress(scanner.next());

        System.out.print("Enter the Student totalmarks: ");
        student.setTotalmarks(scanner.nextInt());

        studentRepository.save(student);
        System.out.println("Student inserted successfully.\n");
    }

    private void displayStudents(StudentRepository studentRepository) {
        List<Student> students = studentRepository.findAll();

        if (students.isEmpty()) {
            System.out.println("No students found.\n");
        } else {
            System.out.println("List of Students:");
            for (Student student : students) {
                System.out.println(student.toString());
            }
            System.out.println();
        }
    }
}

