package com.program6.demo;

//package com.example.demo;

import javax.persistence.*;

@Entity
@Table(name = "Student")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private int totalmarks;

    @Column
    private String usn, name, address;

    // Getters and setters, toString method
}

