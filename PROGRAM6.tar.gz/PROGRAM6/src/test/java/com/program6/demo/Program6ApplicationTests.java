package com.program6.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
