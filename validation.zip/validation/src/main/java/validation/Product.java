package validation;
//
//public class Product {
//
//}
//package com.example.RestExample_validate;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Product {

    @NotNull(message = "id is required")
    @Min(value = 1, message = "id should be greater than or equal to 1")
    @Max(value = 100, message = "id should be less than or equal to 100")
    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @Min(value = 1, message = "Price should be greater than or equal to 1")
    @NotNull(message = "Price is required")
    private Double price;

    // Constructors, getters, and setters

    public Product() {
        // Default constructor
    }

    public Product(Long id, String name, Double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    // toString method for better logging and debugging

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}
